from PIL import Image
from numpy import *
from pylab import *
import os

def process_image(imagename,resultname,params="--edge-thresh 10 --peak-thresh 5",resize=None):
	""" Process an image and save the results in a file """

        im = Image.open(imagename).convert('L')
        if resize!=None:
          im = im.resize(resize)
        m,n = im.size

	if imagename[-3:] != 'pgm':
	  # create a pgm file
	  im.save('tmp.pgm')
	  imagename = 'tmp.pgm'

	cmmd = str("vlfeat/bin/glnxa64/sift "+imagename+" --output="+resultname+" "+params)
	os.system(cmmd)
	print 'processed', imagename, 'to', resultname

def read_features_from_file(filename):
	""" Read feature properties and return in matrix form """

	f = loadtxt(filename)
	return f[:,:4],f[:,4:]
